#include"Functionalitie.h"
#include"IdnotFond.h"

int main(){
    Engine *arr[4]{nullptr};
    CreateObjects(arr,4);
    try
    {
         float avg = AverageHorsePower(arr,4);
        std::cout<<"Avg Power :" <<avg <<std::endl;
    }
    catch(std::invalid_argument& e)
    {
        std::cerr << e.what() << '\n';
    }
    try
    {
        FindTorqueById(arr,4,105);
    }
    catch(std::invalid_argument& e)
    {
        std::cerr << e.what() << '\n';
    }
    catch(IdnotFond& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        FindHorsepowerForMinTorqueEngine(arr,4);   
    }
    catch(std::invalid_argument& e)
    {
        std::cerr << e.what() << '\n';
    }
   DeleteObjects(arr,4);
}