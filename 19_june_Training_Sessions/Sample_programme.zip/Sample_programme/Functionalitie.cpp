#include "Functionalitie.h"
#include "IdnotFond.h"

void CreateObjects(Engine **arr, int size)
{
    // arr[0] = new Engine(0,21,2.0);
    // arr[1] = new Engine(102,22,3.0);
    // arr[2] = new Engine(103,23,4.0);
    // arr[3] = new Engine(104,24,5.0);
    int id;
    int horsepower;
    float torque;
    for( int i = 0; i < size ; i++){
        std::cin>>id;
        std::cin>>horsepower;
        std::cin>>torque;
        arr[i] = new Engine(id,horsepower,torque);
    }
}

float AverageHorsePower(Engine **arr, int size)
{
    if(size < 0){
        throw std::invalid_argument("Size Cannot be Negative");
    }
    int sum = 0;
    int count = 0;
    for(int i = 0; i < size ; i++){
        if(arr[i]){
        sum = sum + arr[i] ->horsepower();
        count++;
    }
}
    if(count == 0){
        throw std::invalid_argument("insufficient objcets");
    }
    else{
        return sum/count;
    }
    
}

void FindTorqueById(Engine **arr, int size , int id)
{
    if(size < 0){
        throw std::invalid_argument("Size Cannot be Negative");
        return;
    }
    bool value = false;
    for( int i = 0; i < size ; i++){
        if(arr[i]->id() == 0){
            throw std::invalid_argument("Id Cannot be null");
            break;
        }
        if(arr[i]->id()== id){
            std::cout<<"Torque :"<< arr[i]->torque()<<std::endl;
            value = true;
            
        }
    }
    if(!value){
        throw IdnotFond("Id Not Found");
    }
    
}

void FindHorsepowerForMinTorqueEngine(Engine **arr, int size)
{
    if(size < 0){
        throw std::invalid_argument("Size Cannot be Negative");
        return;
    }
    int min = 0;
    int horsep = 0;
    for(int i = 0 ; i < size-1 ; i++){
        if(arr[i] -> torque() <= arr[i+1]->torque()){
            min = arr[i]->torque();
            horsep = i;
        }
        
    }
    std::cout<<"Horse Power:"<<arr[horsep]->horsepower()<<std::endl;
}

void DeleteObjects(Engine **arr, int size)
{
    for(int i = 0; i < size; i++){
        delete arr[i];
    }
}
