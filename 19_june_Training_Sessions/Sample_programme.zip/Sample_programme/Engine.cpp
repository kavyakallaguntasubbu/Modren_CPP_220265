#include "Engine.h"

Engine::Engine(unsigned int id, unsigned int horsePower, float torque)
    : m_id{id},m_horsepower{horsePower},m_torque{torque}{
            
}
