#ifndef FUNCTIONALITIE_H
#define FUNCTIONALITIE_H

#include"Engine.h"

void CreateObjects(Engine **arr,int size);

float AverageHorsePower(Engine **arr, int size);

void FindTorqueById(Engine **arr, int size , int id);

void FindHorsepowerForMinTorqueEngine(Engine **arr, int size);

void DeleteObjects(Engine **arr,int size);

#endif // FUNCTIONALITIE_H
