#include "Device.h"

Device::Device(std::string id, std::string name, float price)
    :_ID{id},_name{name},_price{price}
{

}