#include"Functionalities.h"

int main(){
    Container arr;
    CreateObjcets(arr);
    FindSensorReadings(arr,104);
    MaxGst(arr);
    DeleteObjects(arr);

}