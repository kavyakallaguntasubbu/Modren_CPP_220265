#include"Functionalities.h"

int main(){
    Smartdevice *arr[3];
    CreateObjects(arr,3);
    try
    {
        IndexValue(arr,3,1);
    }
    catch( std::invalid_argument& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
        std::string gst = MaxGSTCost(arr,3);
        std::cout<<"Max Gst " << gst << std::endl;
    }
    catch( std::invalid_argument& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    for(int i = 0 ; i< 3;i++){
        std::cout<< *arr[i] << std::endl;
    }

    DeleteHeapobjects(arr,3);
}