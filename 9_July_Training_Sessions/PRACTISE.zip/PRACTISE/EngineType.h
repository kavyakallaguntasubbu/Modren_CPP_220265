#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    HYBRID,
    ICE,
    ALTERNATIVE_FUEL
};

#endif // ENGINETYPE_H
