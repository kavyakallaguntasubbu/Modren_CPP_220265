#ifndef STACKEMPTY_H
#define STACKEMPTY_H

#include<stdexcept>
#include<iostream>
 
class StackEmpty :public std::exception
{
private:
    std::string m_msg{""};
public:
    StackEmpty(std::string msg):m_msg{msg}{}
    ~StackEmpty() {}

     virtual const char*
    what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_NOTHROW{
        return m_msg.c_str();
    }

};

#endif // STACKEMPTY_H
