/*
    Note : a template functions's declaration and definition annot be rin 2 separate
    translation units (files)
*/

#ifndef STACK_H
#define STACK_H

#include <vector>
#include "StackEmpty.h"

template <typename T>

class stack
{
private:
    std::size_t m_top{-1};
    std::vector<T> m_data{};

public:
    stack() = default; // defaulted default constructor
    stack();
    ~stack() = default;
    stack(const stack<T> &) = default;
    stack(stack<T> &&) = default;
    stack &operator=(const stack<T> &) = default;
    stack &operator=(stack<T> &&) = default;
    stack(const std::vector<T> &values);             // user has a vector , we copy it into a new stack
    stack(const std::initializer_list<T> &values); // stack<int> s1 {1,2,3}

    T Pop();

   void Push(const T element); // const reference means lvalues and rvalues are also referred
   void Push(const T &&element);

    T &Peek(); // just referencing --- just seeing

    bool IsEmpty();

    void Swap(stack<T> &other);

    std::size_t size();

    void Clear();

    stack<T> Merge(const stack<T> &other);

};

template <typename T>
inline stack<T>::stack(const std::vector<T> &values)
{
    for(const T elm : values){
        m_top++;
        m_data.push_back(elm);
    }
}

template <typename T>
inline stack<T>::stack(const std::initializer_list<T> &values)
{
    for(const T elm : values){
        m_top++;
        m_data.push_back(elm);
    }
}

template <typename T>
inline T stack<T>::Pop()
{
    if (IsEmpty())
    {
        throw StackEmpty("Stack empty :")
    }
    // we need to return the popped item to the user. so we must copy it safely somewhere
    T element = m_data[m_top];
    m_data.pop_back(element);

    }

    template <typename T>
    inline void stack<T>::Push(const T element)
    {
        m_top++;
        m_data.push_back(element);
    }

    template <typename T>
    inline void stack<T>::Push(const T &&element)
    {
        m_top++;
        m_data.push_back(element);
    }

    template <typename T>
    inline T &stack<T>::Peek()
    {
        if (IsEmpty())
        {
            throw StackEmpty("Stack empty. Cannot peek")
        }
        return m_data[m_top--];
    }

    template <typename T>
    inline bool stack<T>::IsEmpty()
    {
        if (IsEmpty())
        {
            throw StackEmpty("Stack empty :")
        }
        return m_data[m_top--];
    }

    template <typename T>
    inline void stack<T>::Swap(stack<T> &other)
    {
        m_data.swap(other.m_data); // swap this stack's m_data with other stck's m_data;
    }

    template <typename T>
    inline std::size_t stack<T>::size()
    {
        return m_data.size();
    }

    template <typename T>
    inline void stack<T>::Clear()
    {
        m_data.erase(m_data.begin(),m_data.end());
    }

    template <typename T>
    inline stack<T> stack<T>::Merge(const stack<T> &other)
    {
        // stack<T> result{};
        // for(const T elem : this->m_data){
        //     result.m_data.push_back(elem);
        // }
        // for(const T elem : other->m_data){
        //     result.m_data.push_back(elem);
        // }

        // return result;
        for(std::size_t i = 0; i < other.size(); i++){
            this->Push(other.Pop());
        }
        return result;

    }

#endif // STACK_H
